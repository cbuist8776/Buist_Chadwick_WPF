/*
 * Chadwick Buist
 * WPF 1408 Section 1
 * Industry Specific Expression
 * 8-14-2014
 */
//How many website clients to reach $1500 in profit at $100 per client. How many clients at $120 per client? How many clients at $140 per client?

//Figure out how many clients it would take to bank $1500 total.

var client = 100 + "dollars";

var client2 = 120 + "dollars";

var client3 = 140 + "dollars";

//Calculate how many clients to reach $1500 at $100 per client.

var oneHundred = 1500/100;

//Write to var oneHundred to console

console.log(oneHundred);

//Set up Alert to user for var oneHundred

alert( "You need " + "" + oneHundred + " " + "clients to reach 1500 dollars in profit");

//Calculate how many clients to reach $1500 at $120 per client

var oneHundredTwenty = 1500/120;

//Write var oneHundredTwenty to console

console.log(oneHundredTwenty)

//Alert business owner of how many clients to get to $1500 in profit at $120 per client

alert ("You need " + "" + oneHundredTwenty + "" + "clients to reach 1500 in profit");

//Calculate how many clients to reach $1500 at $140 per client

var oneHundredForty = 1500/140;

//Write var oneHundredForty to console

console.log(oneHundredForty);

//Alert the owner how many clients to get $1500 in profit at $140 per client

alert ("You need " + "" + oneHundredForty + "" + "clients to reach 1500 in profit");





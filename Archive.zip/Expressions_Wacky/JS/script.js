/*
 * Chadwick Buist
 * WPF 1408 Section 1
 * Wacky Expression
 * 8-14-2014
 */
//How many strokes per 25,50,and 100 meters will occur?

//Given

var stroke = 5/5 + "meters";

//Calculate number of strokes per 25 meters.

var twentyFive = 25*1;

//Write var twentyFive to the console

console.log(twentyFive);

//Alert the athlete for the number of strokes per 25 meters

alert("At one stroke per meter you will take" + "" + twentyFive + "" + "strokes per 25 meters");

//Calculate number of strokes per 50 meters.

var fiftyMeters = 50*1

console.log(fiftyMeters)

alert("At one stroke per meter you will take" + "" + fiftyMeters + "" + "strokes per 25 meters");

//Calculate number of strokes per 100 meters

var oneHundred = 100*1

console.log(oneHundred);

alert("At one stroke per meter you will take" + "" + oneHundred + "" + "strokes per 25 meters");
